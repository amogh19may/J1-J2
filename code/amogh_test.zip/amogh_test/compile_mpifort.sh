module load intel2020
mpiifort -cpp -O3 par_OVR.f90 -o myprog.exe 
